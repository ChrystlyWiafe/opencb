	--DECLARE @beginDate     DATETIME = CAST(DATEADD(M, -1, GETDATE()) AS DATE),
	--        @endDate       DATETIME = CAST(GETDATE() AS DATE),
	--        @disbursed_in  INT = 0,
	--        @display_in    INT = 1,
	--        @branch_id     INT = 1
	
	SELECT cc.close_date
	      ,co.contract_code
	      ,substring(cc.client_name,0,CHARINDEX(' ',cc.client_name)) as client_first_name
          ,substring(cc.client_name,CHARINDEX(' ',cc.client_name),LEN(cc.client_name)) as client_last_name
          ,pa.name
	      ,cc.loan_officer
	      ,ce.event_date AS disb_date
	      ,cc.amount * dbo.GetXR(cc.currency_id, @display_in, cc.close_date) AS amount
	      ,cc.currency
	FROM   ClosedContracts(@beginDate, @endDate, @branch_id) cc
	       INNER JOIN Contracts co
	            ON  co.id = cc.contract_id
	       INNER JOIN Credit cr
	            ON  cr.id = cc.contract_id
	       INNER JOIN Packages pa
	            ON  pa.id = cr.package_id
	       INNER JOIN ContractEvents ce
	            ON  co.id = ce.contract_id
	            AND ce.event_type = 'LODE'
	            AND ce.is_deleted = 0
	WHERE  (cc.currency_id = @disbursed_in OR 0 = @disbursed_in)
	ORDER BY
	       close_date,
	       loan_officer