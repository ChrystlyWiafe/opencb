CREATE PROCEDURE dbo.Rep_Corporate_Loan_Agreement @contract_id INT
AS
BEGIN
SELECT LEFT(Credit.amount,LEN([Credit].amount)-3) AS amount,
		[Credit].[interest_rate], 
		[Credit].[nb_of_installment], 
		Contracts.contract_code, 
		Contracts.[start_date], 
		corporates.name AS client_name,
		users.first_name+' '+users.[last_name] AS lo_name,
		dbo.getEntryFees(@contract_id) AS [entry_fees],
	    [Credit].[non_repayment_penalties_based_on_overdue_principal],
	   (SELECT [value] 
	    FROM [GeneralParameters] 
	    WHERE [KEY] = 'BRANCH_NAME') AS branch_name,
	    
	    LEFT((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] 
	    WHERE [Installments].[contract_id] = @contract_Id),
	    LEN((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] 
	    WHERE [Installments].[contract_id] = @contract_Id))-3) AS loan_cost,
	    
	    LEFT((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] 
	    WHERE [Installments].[contract_id] = @contract_Id AND number=1),
	    (LEN((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] 
	    WHERE [Installments].[contract_id] = @contract_Id AND number=1))-3)) AS instalment_cost
	    
	   
FROM Credit 
INNER JOIN 	 Contracts ON Contracts.id =Credit.id 
INNER JOIN 	 Projects ON Projects.id = Contracts.[project_id]
INNER JOIN 	 Tiers ON [Tiers].id = Projects.[tiers_id] 
INNER JOIN 	 [Corporates] ON [Corporates].id = [Tiers].[id] 
INNER JOIN	 [Users] ON [Users].id = [loanofficer_id]
INNER JOIN   [Packages] ON [Packages].[id]=[Credit].[package_id]
	 
WHERE credit.id=@contract_Id
END