CREATE PROCEDURE [dbo].[Rep_Contract_History_Repayment_Schedule] @contract_id INT
AS 
    BEGIN
        SELECT  i.number,
                i.[capital_repayment],
                i.[interest_repayment],
                i.[capital_repayment] + i.[interest_repayment] - i.paid_capital - i.paid_interest AS total,
				i.paid_interest,
				i.paid_capital,
                i.[expected_date],
                case when i.[capital_repayment] + i.[interest_repayment] - i.paid_capital - i.paid_interest <0.2
				then (select max(paid_date) from installments 
				where installments.contract_id=i.contract_id and installments.number<=i.number) else NULL end as paid_date
        FROM    [Installments] AS i
        WHERE   [contract_id] = @contract_id
        ORDER BY i.[number] ASC
    END
