Create PROCEDURE [dbo].[Rep_Contract_History_Events] @contract_id int
as 
begin 

select event_type, event_date, SUM(principal) as principal, SUM(interests) as interests, SUM(fees) as fees, late_days from 
(select	event_type, event_date, principal, interests, (commissions + penalties) AS fees, 
(SELECT CASE WHEN retval.expected_date IS NULL THEN 0 ELSE DATEDIFF(dd, retval.expected_date, con1ev.event_date) END AS late_days
	FROM
	(
		SELECT loans.*, MIN(i.expected_date) AS expected_date
		FROM
		(
			SELECT t1.id, t2.interest, t1.paid_interest, t1.principal, t1.paid_principal
			FROM
			(
				-- Get contract id, total due principal, paid principal, and paid interest
				SELECT c.id, 
				c.amount AS principal, 
				SUM(ISNULL(re.principal, 0)) AS paid_principal,
				SUM(ISNULL(re.interests, 0)) AS paid_interest,
				SUM(CASE WHEN 'WROE' = ce.event_type THEN 1 ELSE 0 END) AS wroe,
				SUM(CASE WHEN 'LODE' = ce.event_type THEN 1 ELSE 0 END) AS lode
				FROM dbo.Credit AS c
				LEFT JOIN dbo.ContractEvents AS ce ON ce.contract_id = c.id AND ce.id < con1ev.id AND ce.is_deleted = 0
				LEFT JOIN dbo.RepaymentEvents AS re ON re.id = ce.id
				where c.id=@contract_id
				GROUP BY c.id, c.amount
			) AS t1
			LEFT JOIN
			(
				-- Get interest due
				SELECT contract_id, SUM(interest) AS interest
				FROM dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id)
				GROUP BY contract_id
			) AS t2 ON t1.id = t2.contract_id
			WHERE t1.wroe < 1 AND t1.lode > 0
			AND (t1.principal - t1.paid_principal > 0.5 OR t2.interest - t1.paid_interest > 0.5)
		) AS loans
		-- Get installments that have not been repaid
		-- (necessary to get late days)
		LEFT JOIN
		(
			SELECT a.contract_id, a.number, 
			SUM(b.principal + b.interest) AS running_total, a.expected_date
			FROM dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id) AS a
			LEFT JOIN dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id) AS b ON a.contract_id = b.contract_id AND b.number <= a.number
			GROUP BY a.contract_id, a.number, a.expected_date
		) AS i ON i.contract_id = loans.id 
		AND (loans.paid_principal + loans.paid_interest) < i.running_total
		AND i.expected_date < con1ev.event_date
		GROUP BY loans.id, loans.interest, loans.paid_interest, loans.principal, loans.paid_principal
	) AS retval) as late_days
from	contractevents as con1ev
		inner join repaymentevents on repaymentevents.id=con1ev.id
where	is_deleted=0 and contract_id=@contract_id
union all 
select	event_type, event_date, amount as principal, 0 as interests, fees, 0 as late_days
from	contractevents
		inner join LoanDisbursmentEvents on LoanDisbursmentEvents.id=contractevents.id
where	is_deleted=0 and contract_id=@contract_id
union all 
select	event_type, event_date, amount as principal, 0 as interests, 0 as fees, 
(SELECT CASE WHEN retval.expected_date IS NULL THEN 0 ELSE DATEDIFF(dd, retval.expected_date, con1ev.event_date) END AS late_days
	FROM
	(
		SELECT loans.*, MIN(i.expected_date) AS expected_date
		FROM
		(
			SELECT t1.id, t2.interest, t1.paid_interest, t1.principal, t1.paid_principal
			FROM
			(
				-- Get contract id, total due principal, paid principal, and paid interest
				SELECT c.id, 
				c.amount AS principal, 
				SUM(ISNULL(re.principal, 0)) AS paid_principal,
				SUM(ISNULL(re.interests, 0)) AS paid_interest,
				SUM(CASE WHEN 'WROE' = ce.event_type THEN 1 ELSE 0 END) AS wroe,
				SUM(CASE WHEN 'LODE' = ce.event_type THEN 1 ELSE 0 END) AS lode
				FROM dbo.Credit AS c
				LEFT JOIN dbo.ContractEvents AS ce ON ce.contract_id = c.id AND ce.id < con1ev.id AND ce.is_deleted = 0
				LEFT JOIN dbo.RepaymentEvents AS re ON re.id = ce.id
				where c.id=@contract_id
				GROUP BY c.id, c.amount
			) AS t1
			LEFT JOIN
			(
				-- Get interest due
				SELECT contract_id, SUM(interest) AS interest
				FROM dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id)
				GROUP BY contract_id
			) AS t2 ON t1.id = t2.contract_id
			WHERE t1.wroe < 1 AND t1.lode > 0
			AND (t1.principal - t1.paid_principal > 0.5 OR t2.interest - t1.paid_interest > 0.5)
		) AS loans
		-- Get installments that have not been repaid
		-- (necessary to get late days)
		LEFT JOIN
		(
			SELECT a.contract_id, a.number, 
			SUM(b.principal + b.interest) AS running_total, a.expected_date
			FROM dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id) AS a
			LEFT JOIN dbo.InstallmentSnapshotForLoan(con1ev.event_date, @contract_id) AS b ON a.contract_id = b.contract_id AND b.number <= a.number
			GROUP BY a.contract_id, a.number, a.expected_date
		) AS i ON i.contract_id = loans.id 
		AND (loans.paid_principal + loans.paid_interest) < i.running_total
		AND i.expected_date < con1ev.event_date
		GROUP BY loans.id, loans.interest, loans.paid_interest, loans.principal, loans.paid_principal
	) AS retval) as late_days
from	contractevents as con1ev
		inner join ReschedulingOfALoanEvents on ReschedulingOfALoanEvents.id=con1ev.id
where	is_deleted=0 and contract_id=@contract_id) as events
GROUP BY event_type, event_date, late_days
order by events.event_date

end