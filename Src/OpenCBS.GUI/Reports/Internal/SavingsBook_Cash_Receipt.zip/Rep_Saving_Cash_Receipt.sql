CREATE PROCEDURE dbo.Rep_Saving_Cash_Receipt @saving_id INT
AS
BEGIN
	DECLARE @last_event_id INT,
			@balance_before MONEY
	SET @last_event_id = (SELECT MAX(id) FROM SavingEvents WHERE deleted=0 AND contract_id = @saving_id AND code IN ('SVIE', 'SVDE', 'SVWE', 'SDTE','SOCE','SODE'))
	SET	@balance_before = 
			ISNULL((SELECT SUM(amount) AS "sum_deposit"
					FROM [dbo].[SavingEvents]	
					WHERE deleted=0
						AND (code = 'SVIE' OR code = 'SVDE' OR code = 'SIPE' OR code = 'SCTE' OR code = 'SOCE')
						AND id < @last_event_id
						AND contract_id = @saving_id), 0) -
			ISNULL((SELECT SUM(amount + ISNULL(fees, 0)) AS "sum_withdraw"
					FROM [dbo].[SavingEvents]	
					WHERE deleted=0
						AND (code = 'SVWE' OR code = 'SDTE' OR code = 'SODE')
						AND id < @last_event_id
						AND contract_id = @saving_id), 0)

	SELECT	SavingContracts.code AS "contract_code", 
			ISNULL(Groups.name,Persons.first_name + SPACE(1) + Persons.last_name) AS "client_name",
			Districts.name AS "district_name",
			@balance_before AS "balance_before_last_event",
			CASE SavingEvents.code 
				WHEN 'SVIE' THEN @balance_before + SavingEvents.amount
				WHEN 'SVDE' THEN @balance_before + SavingEvents.amount
				WHEN 'SOCE' THEN @balance_before + SavingEvents.amount
				WHEN 'SVWE' THEN @balance_before - SavingEvents.amount - ISNULL(SavingEvents.fees, 0)
				WHEN 'SDTE' THEN @balance_before - SavingEvents.amount - ISNULL(SavingEvents.fees, 0)
				WHEN 'SODE' THEN @balance_before - SavingEvents.amount - ISNULL(SavingEvents.fees, 0)
			END AS "balance_after_last_event",
			CASE SavingEvents.code 
				WHEN 'SVIE' THEN 'Initial Deposit'
				WHEN 'SVDE' THEN 'Deposit'
				WHEN 'SVWE' THEN 'Withdraw'
				WHEN 'SDTE' THEN 'Transfer'
				WHEN 'SOCE' THEN 'Special Operation'
				WHEN 'SODE' THEN 'Special Operation'
			END AS "last_event",
			SavingEvents.amount AS "last_event_amount",	
			ISNULL(SavingEvents.fees, 0) AS "last_event_fees",
			SavingEvents.creation_date AS "last_event_date",
			Currencies.code as "currency_code"
	FROM [dbo].[SavingContracts]
	INNER JOIN [dbo].[Tiers] ON SavingContracts.tiers_id = Tiers.id
	INNER JOIN [dbo].[Districts] ON Districts.id = Tiers.district_id
	INNER JOIN [dbo].[SavingEvents] ON SavingEvents.contract_id = SavingContracts.id AND SavingEvents.id = @last_event_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	WHERE SavingContracts.id =  @saving_id AND SavingEvents.deleted=0
END