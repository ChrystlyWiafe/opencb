CREATE PROCEDURE dbo.Rep_Saving_Agreement @saving_id INT
AS
BEGIN
	SELECT	SavingContracts.code AS "contract_code", 
			SavingContracts.creation_date AS "contract_creation_date",
			SavingProducts.name AS "product_name",
			ISNULL(Groups.name,Persons.first_name + SPACE(1) + Persons.last_name) AS "client_name",
			Districts.name AS "district_name",
			SavingContracts.interest_rate * 100 AS "interest_rate",
			SavingProducts.balance_max AS "balance_max",
			SavingProducts.balance_min AS "balance_min", 
			SavingProducts.initial_amount_min AS "initial_amount_min",
			SavingProducts.initial_amount_max AS "initial_amount_max", 
			SavingProducts.deposit_max AS "deposit_max", 
			SavingProducts.deposit_min AS "deposit_min", 
			SavingProducts.withdraw_max AS "withdraw_max", 
			SavingProducts.withdraw_min AS "withdraw_min",
			SavingProducts.transfer_min AS "transfer_min",
			SavingProducts.transfer_max AS "transfer_max",
			SavingProducts.entry_fees AS "entry_fees",
			CASE TermDepositProducts.withdrawal_fees_type 
				WHEN 0 THEN CONVERT(VARCHAR, 'Amount')
				WHEN 1 THEN CONVERT(VARCHAR, 'Interests')
			END AS "withdraw_fees_type",
			SavingDepositContracts.withdrawal_fees * 100 AS "withdraw_fees",
			InstallmentTypes.name AS "periodicity",
			SavingDepositContracts.number_periods AS "number_periods",
			CASE TermDepositProducts.interest_frequency
				WHEN 1 THEN CONVERT(VARCHAR, 'Daily')
				WHEN 10 THEN CONVERT(VARCHAR, 'Maturity')
			END	AS "interest_base",
			CASE SavingDepositContracts.rollover
				WHEN 1 THEN CONVERT(VARCHAR, 'None')
				WHEN 2 THEN CONVERT(VARCHAR, 'Principal')
				WHEN 3 THEN CONVERT(VARCHAR, 'Principal and Interests')
			END AS "rollover",
			SavingDepositContracts.transfer_account AS "transfer_account",
			Currencies.code as "currency_code"
	FROM [dbo].[SavingContracts]
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Tiers] ON SavingContracts.tiers_id = Tiers.id
	INNER JOIN [dbo].[Districts] ON Districts.id = Tiers.district_id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	LEFT OUTER JOIN [dbo].[TermDepositProducts] ON TermDepositProducts.id = SavingProducts.id
	LEFT OUTER JOIN [dbo].[SavingDepositContracts] ON SavingDepositContracts.id = SavingContracts.id
	LEFT OUTER JOIN [dbo].[InstallmentTypes] ON InstallmentTypes.id = TermDepositProducts.installment_types_id
	LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	WHERE SavingContracts.id = @saving_id
END
