CREATE PROCEDURE dbo.Rep_NSG_Repayment_Schedule @village_id INT
AS BEGIN

    SELECT i.*,c.*
    FROM (
			SELECT i.contract_id,i.number, i.capital_repayment, i.interest_repayment,
			cr.amount - SUM(i2.capital_repayment) AS olb, i.capital_repayment + i.interest_repayment AS total,
			i.expected_date
			FROM dbo.Installments AS i
			INNER JOIN dbo.Credit AS cr ON cr.id = i.contract_id
			INNER JOIN dbo.Contracts co on co.id = cr.id
			INNER JOIN dbo.Projects pr ON pr.id = co.project_id
			INNER JOIN dbo.VillagesPersons vp ON vp.person_id = pr.tiers_id AND vp.village_id = @village_id
			LEFT JOIN dbo.Installments AS i2 ON i.contract_id = i2.contract_id AND i2.number <= i.number
			--WHERE i.contract_id = @contract_id
			GROUP BY cr.amount, i.contract_id, i.number, i.capital_repayment, i.interest_repayment, i.expected_date
		) i
	INNER JOIN (
				SELECT c.id contract_id,
				  c.contract_code,
				  c.start_date,
				  cr.amount,
				  dbo.getEntryFees(c.id) AS entry_fees,
				  cr.nb_of_installment,
				  u.first_name + ' ' + u.last_name AS loan_officer,
				  t.id AS client_id,
				ISNULL(corp.[name], ISNULL(g.[name], p.first_name + ' ' + p.last_name)) AS client_name
				FROM dbo.Contracts AS c
				INNER JOIN dbo.Credit AS cr ON cr.id = c.id	
				INNER JOIN dbo.Users AS u ON cr.loanofficer_id = u.id
				INNER JOIN dbo.Projects AS j ON c.project_id = j.id
				INNER JOIN dbo.Tiers AS t ON j.tiers_id = t.id
				INNER JOIN dbo.Packages ON Packages.id= cr.package_id
				INNER JOIN dbo.VillagesPersons vp ON vp.person_id = t.id
				INNER JOIN dbo.Villages v ON v.id = vp.village_id AND v.id = @village_id
				LEFT JOIN dbo.Persons AS p ON t.id = p.id
				LEFT JOIN dbo.Groups AS g ON t.id = g.id
				LEFT JOIN dbo.Corporates AS corp ON t.id = corp.id
				) c ON i.contract_id = c.contract_id
END