CREATE PROCEDURE Rep_Client_Solidarity_Group_Information
	@group_id INT
	, @branch_id INT
AS BEGIN
	IF OBJECT_ID('tempdb..#thumbnails') IS NOT NULL
	BEGIN
	   DROP TABLE #thumbnails
	END

	CREATE TABLE #thumbnails	
	(
		num INT NOT NULL
		, thumbnail1 IMAGE NULL
		, thumbnail2 IMAGE NULL	
		, week_day nvarchar(30)
	)

	DECLARE @db_from NVARCHAR(MAX)
	DECLARE @db_to NVARCHAR(MAX)
	DECLARE @sql NVARCHAR(MAX)

	SELECT @db_from = DB_NAME()
	SET @db_to = @db_from + '_attachments'

	IF EXISTS (SELECT * FROM sys.databases WHERE name = @db_to)
	BEGIN
		SET @sql = 'INSERT INTO #thumbnails (num, thumbnail1)
		SELECT 1, thumbnail
		FROM ' + @db_to + '..Pictures
		WHERE id = ' + CAST(@group_id AS NVARCHAR(20)) + ' AND subid = 0'
		EXEC sp_executesql @sql	

		SET @sql = 'INSERT INTO #thumbnails (num, thumbnail2)
		SELECT 2, thumbnail
		FROM ' + @db_to + '..Pictures
		WHERE id = ' + CAST(@group_id AS NVARCHAR(20)) + ' AND subid = 1'
		EXEC sp_executesql @sql	
	END


	SELECT
	Gr.name
	,CONVERT(char(10), Gr.establishment_date, 104) as establishment_date
	,Gr.comments
	,B.name as branch_name
    ,week_day = CASE
     WHEN Gr.meeting_day = 1 THEN 1
     WHEN Gr.meeting_day = 2 THEN 2
     WHEN Gr.meeting_day = 3 THEN 3
     WHEN Gr.meeting_day = 4 THEN 4
	 WHEN Gr.meeting_day = 5 THEN 5
	 WHEN Gr.meeting_day = 6 THEN 6
	 WHEN Gr.meeting_day = 7 THEN 7
    END
  	,Gr.loan_officer_id
	,ISNULL(Dis.name, '-') AS [district]
	,ISNULL(Tr.city, '-') AS [city]
	,ISNULL(Tr.address, '-') AS [address]
	,ISNULL(Dis2.name, '-') AS [sec_district]
	,ISNULL(Tr.secondary_city, '-') AS [sec_city]
	,ISNULL(Tr.secondary_address, '-') AS [sec_address]
	,ISNULL(Tr.personal_phone, '-') AS [phone]
	,ISNULL(Tr.secondary_home_phone, '-') AS [sec_phone], ISNULL(Tr.secondary_personal_phone, '-') AS [sec_pers_phone]
	, th1.thumbnail1 picture
	, th2.thumbnail2 picture2
	FROM Tiers AS Tr
	INNER JOIN Branches as B on B.id = Tr.branch_id
	INNER JOIN Groups AS Gr ON Gr.id = Tr.id
	LEFT JOIN Districts AS Dis ON Dis.id = Tr.district_id
	LEFT JOIN Districts AS Dis2 ON Dis2.id = Tr.secondary_district_id
	LEFT JOIN #thumbnails th1 ON th1.num = 1
	LEFT JOIN #thumbnails th2 ON th2.num = 2
	WHERE Tr.id = @group_id

END