CREATE PROCEDURE dbo.Rep_Saving_Contract_Info @saving_id INT
AS
BEGIN
	SELECT	GETDATE() AS [date_of_day],
	DATEADD(MONTH, -4, GETDATE()) AS [date_before],
	SavingContracts.code AS [contract_code], 
	SavingContracts.creation_date AS [contract_creation_date],
	ISNULL(Groups.name,Persons.first_name + SPACE(1) + Persons.last_name) AS [client_name], 
	dbo.getSavingBalance(@saving_id, DATEADD(MONTH, -4, GETDATE())) AS [account_cash],
	dbo.getSavingBalance(@saving_id, GETDATE()) AS [account_cash_after],
	Currencies.code as [currency_code]
	FROM [dbo].[SavingContracts]
	INNER JOIN [dbo].[Tiers] ON SavingContracts.tiers_id = Tiers.id
	INNER JOIN [dbo].[Districts] ON Districts.id = Tiers.district_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	WHERE SavingContracts.id = @saving_id
END