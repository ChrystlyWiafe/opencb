CREATE PROCEDURE dbo.Rep_Saving_Contract_Info @saving_id INT
AS
BEGIN
	SELECT	GETDATE() AS "date_of_day",
			SavingContracts.code AS "contract_code", 
			SavingContracts.creation_date AS "contract_creation_date",
			ISNULL(Groups.name,Persons.first_name + SPACE(1) + Persons.last_name) AS "client_name", 
			(SELECT balance
			 FROM [dbo].[SavingAccountsBalance]
			 WHERE saving_id = SavingContracts.id AND account_number = '223') AS "account_savings",
			(SELECT balance
			 FROM [dbo].[SavingAccountsBalance]
			 WHERE saving_id = SavingContracts.id AND account_number = '1011') AS "account_cash",
			(SELECT balance
			 FROM [dbo].[SavingAccountsBalance]
			 WHERE saving_id = SavingContracts.id AND account_number = '2263') AS "account_payable_interests", 
			(SELECT balance
			 FROM [dbo].[SavingAccountsBalance]
			 WHERE saving_id = SavingContracts.id AND account_number = '60132') AS "interest_on_deposit_account", 
			(SELECT balance
			 FROM [dbo].[SavingAccountsBalance]
			 WHERE saving_id = SavingContracts.id AND account_number = '7029') AS "commissions", 
			 Currencies.code as "currency_code"
	FROM [dbo].[SavingContracts]
	INNER JOIN [dbo].[Tiers] ON SavingContracts.tiers_id = Tiers.id
	INNER JOIN [dbo].[Districts] ON Districts.id = Tiers.district_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	WHERE SavingContracts.id = @saving_id
END