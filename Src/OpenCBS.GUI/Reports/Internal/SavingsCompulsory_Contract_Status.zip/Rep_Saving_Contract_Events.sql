CREATE PROCEDURE dbo.Rep_Saving_Contract_Events @saving_id INT
AS
BEGIN
	SELECT CASE SavingEvents.code
				WHEN 'SVIE' THEN 'Initial Deposit'
				WHEN 'SVDE' THEN 'Deposit'
				WHEN 'SVWE' THEN 'Withdrawal'
				WHEN 'SIPE' THEN 'Interest Posting'
				WHEN 'SDTE' THEN 'Debit Transfer'
				WHEN 'SCTE' THEN 'Credit Transfer'
				WHEN 'SOCE' THEN 'Special Operation Credit'
				WHEN 'SODE' THEN 'Special Operation Debit'
				WHEN 'SOFE' THEN 'Overdraft Fees'
				WHEN 'SVAE' THEN 'Agio'
				WHEN 'SVDC' THEN 'Deposit Cheque'
				WHEN 'SVRE' THEN 'Reopen'
				WHEN 'SMFE' THEN 'Management Fee'
				WHEN 'SPDE' THEN 'Pending Deposit'
				WHEN 'SPDR' THEN 'Pending Deposit Refused'
				WHEN 'SVCE' THEN 'Closing'
			END AS "event_type", 
			amount, 
			[description],
			[SavingEvents].creation_date AS "creation_date",
			Currencies.code as "currency_code"	
	FROM [dbo].[SavingEvents]
	INNER JOIN [dbo].[SavingContracts] ON SavingContracts.id = SavingEvents.contract_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	WHERE contract_id = @saving_id
	AND SavingEvents.code NOT IN ('SIAE', 'SCLE')
	ORDER BY SavingEvents.id
END