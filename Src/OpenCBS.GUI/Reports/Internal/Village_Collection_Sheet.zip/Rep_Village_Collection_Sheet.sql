CREATE PROCEDURE dbo.Rep_Village_Collection_Sheet 
	@village_id INT
	,@from DATETIME
	,@to DATETIME
	,@display_in INT
	,@branch_id INT
AS BEGIN
	SELECT p.identification_data,
	ISNULL(p.first_name,'') + ISNULL(p.last_name,'') AS client_name,
	v.name AS village_name,
	cr.interest_rate,
	cr.nb_of_installment,
	al.amount,
	cr.loan_cycle,
	al.olb,
	i.principal - i.prepaid_principal AS principal,
	i.interest - i.prepaid_interest AS interest	
	FROM dbo.ExpectedInstallments_MC(@from, @to, 0, @display_in, 0, 0, @branch_id) AS i
	INNER JOIN dbo.Contracts AS c ON c.id = i.contract_id
	INNER JOIN dbo.Credit AS cr ON cr.id = c.id
	INNER JOIN dbo.ActiveLoans_MC(@from, 0, @display_in, @branch_id) AS al ON al.id = c.id
	INNER JOIN dbo.Projects AS j ON j.id = c.project_id
	INNER JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	INNER JOIN dbo.VillagesPersons vp ON vp.person_id = t.id	
	INNER JOIN dbo.Villages v ON v.id = vp.village_id	
	INNER JOIN dbo.Persons p ON p.id = vp.person_id
	WHERE t.branch_id = @branch_id AND v.id = @village_id
	ORDER BY i.expected_date
END
